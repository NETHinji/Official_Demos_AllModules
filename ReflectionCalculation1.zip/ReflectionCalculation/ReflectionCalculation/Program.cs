﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionCalculation
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            Type t = assembly.GetType("ReflectionCalculation.CalculateInterest");
            MethodInfo methodInfo = t.GetMethod("CalculateInterest1", BindingFlags.NonPublic | BindingFlags.Static);
            methodInfo.Invoke(null, new object[] { 22, 3, 2 });
            Console.ReadKey();
        }
    }
    class CalculateInterest
    { 
        private static void CalculateInterest1(int pri, float rate, float noofYears)
        {
            float si = (pri * rate * noofYears) / 100;
            Console.WriteLine("Simple Interest  =  " + si);
        }
    }
}
