﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VisitorManagementSystem.BusinessLogicLayer;
using VisitorManagementSystem.DataAccessLayer;
using VisitorManagementSystem.Entities;
using VisitorManagementSystem.VisitorExceptions;

namespace VisitorManagementSystem.PresentationLayer
{
    class Program
    {

        List<Visitor> visitorList = new List<Visitor>();

        static void Main(string[] args)
        {
           
            
            
            int choice;
            do
            {

                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                
                switch (choice)
                {
                    case 1:

                        AddGuest();
                        break;
                    case 2:
                        ListAllGuests();
                        break;
                    case 3:
                        SearchGuestByID();
                        break;

            
                    case 4:
                        
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;


                }
               
            } while (choice != -1);
        }

        private static void SearchGuestByID()
        {
            try
            {
                int searchVisitorID;
                Console.WriteLine("Enter Visitor Gate Pass ID to Search:");
                searchVisitorID = Convert.ToInt32(Console.ReadLine());
                Visitor searchVisitor = VisitorBLL.SearchVisitorBLL(searchVisitorID);
                if (searchVisitor != null)
                {
                    Console.WriteLine("\t\t\t******************************************************************************");
                    Console.WriteLine("VisitorID\t\tName\t\tDateofVisit\t\tPhoneNumber\t\tPurposeofVisit\t\tContactPerson");
                    Console.WriteLine("\t\t\t******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}", searchVisitor.GatePassId, searchVisitor.VisitorName, 
                                        searchVisitor.DateOfVisit, searchVisitor.Contactno, searchVisitor.PurposeofVisit, searchVisitor.ContactPerson);

                    Console.WriteLine("\t\t\t******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }

            }
            catch (VisitorManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddGuest()
        {
            try
            {
                List<Visitor> visitorList = new List<Visitor>();
                Visitor newVisitor = new Visitor();

                Random rn = new Random();
                int visitorId = rn.Next(10000, 99999);
                newVisitor.GatePassId = visitorId; 
                Console.WriteLine("Enter Visitor Name :");
                newVisitor.VisitorName = Console.ReadLine();

                newVisitor.DateOfVisit = DateTime.Today.Date;
                Console.WriteLine("Enter Contact no of visitor");
                newVisitor.Contactno = Console.ReadLine();
                Console.WriteLine("Enter purpose of visit");
                newVisitor.PurposeofVisit = Console.ReadLine();
                Console.WriteLine("Enter Contact Person Name");
                newVisitor.ContactPerson = Console.ReadLine();

                bool guestAdded = VisitorBLL.AddVisitorBLL(newVisitor);
                if (guestAdded)
                    Console.WriteLine("Guest Added");
                else
                    Console.WriteLine("Guest not Added");
                VisitorDAL.SerializeData(visitorList);
            }
            catch (VisitorManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        private static void ListAllGuests()
        {
            try
            {
                VisitorDAL.DeserializeData();
                List<Visitor> visitorList = VisitorBLL.GetAllVisitorBLL();
                if (visitorList != null)
                {
                    Console.WriteLine("\t\t\t******************************************************************************");
                    Console.WriteLine("VisitorID\t\tName\t\tDateofVisit\t\tPhoneNumber\t\tPurposeofVisit\t\tContactPerson");
                    Console.WriteLine("\t\t\t******************************************************************************");
                    foreach (Visitor visitor in visitorList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}", visitor.GatePassId, visitor.VisitorName,
                                        visitor.DateOfVisit, visitor.Contactno, visitor.PurposeofVisit, visitor.ContactPerson);
                    }
                    Console.WriteLine("\t\t\t******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }
            }
            catch (VisitorManagementException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        private static void PrintMenu()
        {
            Console.WriteLine("\n***********Guest PhoneBook Menu***********");
            Console.WriteLine("1. Add Guest");
            Console.WriteLine("2. List All Guests");
            Console.WriteLine("3. Search  by Gate Pass ID");
            Console.WriteLine("4. Exit");
            Console.WriteLine("******************************************\n");

        }
    }
}
