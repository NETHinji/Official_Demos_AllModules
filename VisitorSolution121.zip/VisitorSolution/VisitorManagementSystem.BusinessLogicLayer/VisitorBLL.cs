﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using VisitorManagementSystem.DataAccessLayer;
using VisitorManagementSystem.Entities;
using VisitorManagementSystem.VisitorExceptions;

namespace VisitorManagementSystem.BusinessLogicLayer
{
    public class VisitorBLL
    {
        private static bool ValidateGuest(Visitor visitor)
        {
            StringBuilder sb = new StringBuilder();
            bool validGuest = true;
            //if (visitor.GatePassId <= 0)
            //{
            //    validGuest = false;
            //    sb.Append(Environment.NewLine + "Invalid Visitor Gate Pass ID");

            //}
            if (visitor.VisitorName == string.Empty)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Visitor Name Required");

            }
            if ((visitor.Contactno.Length < 10 || visitor.Contactno.Length >10) && (visitor.Contactno.StartsWith("9") || visitor.Contactno.StartsWith("8")) )
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }
            if (visitor.PurposeofVisit == string.Empty)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Visitor purpose detail required");

            }
            if (visitor.ContactPerson == string.Empty)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Contact Person name reqired");

            }
            if (validGuest == false)
                throw new VisitorManagementException(sb.ToString());
            return validGuest;
        }



        public static Visitor SearchVisitorBLL(int searchVisitorID)
        {
            Visitor searchVisitor = null;
            try
            {
                VisitorDAL guestDAL = new VisitorDAL();
                searchVisitor = guestDAL.SearchVisitorDAL(searchVisitorID);
            }
            catch (VisitorManagementException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchVisitor;
        }


        public static bool AddVisitorBLL(Visitor newVisitor)
        {
            bool visitorAdded = false;
            try
            {
                if (ValidateGuest(newVisitor))
                {
                    VisitorDAL visitorDAL = new VisitorDAL();
                    visitorAdded = visitorDAL.AddVisitorDAL(newVisitor);
                }
            }
            catch (VisitorManagementException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return visitorAdded;
        }

        public static List<Visitor> GetAllVisitorBLL()
        {
            List<Visitor> visitorList = null;
            try
            {
                VisitorDAL guestDAL = new VisitorDAL();
                visitorList = guestDAL.GetAllVisitorDAL();
            }
            catch (VisitorManagementException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return visitorList;
        }

        
    }
}