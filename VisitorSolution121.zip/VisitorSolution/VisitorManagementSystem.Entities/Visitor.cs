﻿using System;

namespace VisitorManagementSystem.Entities
{

    [Serializable]
    public class Visitor
    {
        private int _GatePassId;
        public int GatePassId
        {
            get { return _GatePassId; }
            set { _GatePassId = value; }
        }
        
        private string _VisitorName;

        public string VisitorName
        {
            get { return _VisitorName; }
            set { _VisitorName = value; }
        }

        private DateTime _DateOfVisit;

        public DateTime DateOfVisit
        {
            get { return _DateOfVisit; }
            set { _DateOfVisit = value; }
        }

        private string _Contactno;

        public string Contactno
        {
            get { return _Contactno; }
            set { _Contactno = value; }
        }
        private string _PurposeofVisit;

        public string PurposeofVisit
        {
            get { return _PurposeofVisit; }
            set { _PurposeofVisit = value; }

        }

        private string _ContactPerson;

        public string ContactPerson
        {
            get { return _ContactPerson; }
            set { _ContactPerson = value; }

        }

        public Visitor()
        {
            GatePassId = 0;
            VisitorName = string.Empty;
            DateOfVisit = DateTime.Now.Date;
            Contactno = string.Empty;
            PurposeofVisit = string.Empty;
            ContactPerson = string.Empty;
        }
    }


        




       
}


