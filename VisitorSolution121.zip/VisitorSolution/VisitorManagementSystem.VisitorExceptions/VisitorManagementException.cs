﻿using System;
using System.Runtime.Serialization;

namespace VisitorManagementSystem.VisitorExceptions
{
    [Serializable]
    public class VisitorManagementException : Exception
    {
        public VisitorManagementException()
        {
        }

        public VisitorManagementException(string message) : base(message)
        {
        }

        public VisitorManagementException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected VisitorManagementException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}