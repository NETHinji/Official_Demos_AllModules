﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using VisitorManagementSystem.Entities;
using VisitorManagementSystem.VisitorExceptions;

namespace VisitorManagementSystem.DataAccessLayer
{
    public class VisitorDAL
    {
        public static List<Visitor> visitorList = new List<Visitor>();

        public bool AddVisitorDAL(Visitor newVisitor)
        {
            bool visitorAdded = false;
            try
            {
                visitorList.Add(newVisitor);
                

                
                visitorAdded = true;
            }
            catch (SystemException ex)
            {
                throw new VisitorManagementException(ex.Message);
            }
            return visitorAdded;
        }

        public Visitor SearchVisitorDAL(int searchVisitor)
        {
            Visitor visitorSearch = null;
            try
            {
                visitorSearch = visitorList.Find(visitor => visitor.GatePassId == searchVisitor);
            }
            catch (SystemException ex)
            {
                throw new VisitorManagementException(ex.Message);
            }
            return visitorSearch;
        }



        public List<Visitor> GetAllVisitorDAL()
        {
               
                return visitorList;
            
        }

        public static void SerializeData(List<Visitor> v1)
        {
            FileStream fileStream = new FileStream("d:\\ser.dat", FileMode.Create);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(fileStream, v1);
            fileStream.Close();
        }

        public static void DeserializeData()
        {
            FileStream fileStream = new FileStream("d:\\ser.dat", FileMode.Open);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            List<Visitor> e1 = (List<Visitor>)binaryFormatter.Deserialize(fileStream);
            fileStream.Close();

        }




    }
}